<?php


//商户号（8位数字）
$shan_config['user_seller'] = '38544469';



//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
//合作身份者PID，签约账号，由16位纯数字组成的字符串，请登录商户后台查看
$shan_config['partner']		= '738513346376621';



// MD5密钥，安全检验码，由数字和字母组成的32位字符串，请登录商户后台查看
$shan_config['key']			= 'JHeP76Kzd8aMQv8GZxZ3Gi8NgI2gfgAW';





// 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
$shan_config['notify_url'] = "http://127.0.0.1/notify_url.php";

// 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
$shan_config['return_url'] = "http://127.0.0.1/return_url.php";

//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

?>